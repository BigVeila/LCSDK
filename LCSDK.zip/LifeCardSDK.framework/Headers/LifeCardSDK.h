//
//  LifeCardSDK.h
//  LifeCardSDK
//
//  Created by BigSun on 6/17/20.
//  Copyright © 2020 BigSun. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "MLTransition.h"
//#import "UITableViewCell+CellShadows.h"
//! Project version number for LifeCardSDK.
FOUNDATION_EXPORT double LifeCardSDKVersionNumber;

//! Project version string for LifeCardSDK.
FOUNDATION_EXPORT const unsigned char LifeCardSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LifeCardSDK/PublicHeader.h>

